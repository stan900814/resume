# resume
前端工程师简历
将前端工程师可以做的事情做到简历里来动态的呈现
在线地址:http://blog.youlunshidai.com/resume/index.html
